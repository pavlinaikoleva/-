#pragma once
#ifndef __EMPLOYEE_H__
#define __EMPLOYEE_H__
#include "date.h"
#include <iostream>
#include <vector>
const int SIZE_CHARS_OF_NAME = 150;
const int SIZE_CHARS_OF_ADDRESS = 200;
const int SIZE_CHARS_OF_EGN = 12;
const int SIZE_CHARS_OF_POSITION = 50;
const int SIZE_CHARS_OF_DATE = 12;
const int SIZE_CHARS_PROJECT = 150;
const int SIZE_CHARS_OS = 60;
class Employee //�� ���� ���������� ����,������� �� ��������� �� �������� �������
{
protected:
	char name[SIZE_CHARS_OF_NAME];
	char address[SIZE_CHARS_OF_ADDRESS];
	char EGN[SIZE_CHARS_OF_EGN];
	Date date;
	Employee *boss;
	char position[SIZE_CHARS_OF_POSITION];
public:
	//����������� �� ������������ ����� ������
	Employee();
	virtual void print()const = 0;
	virtual const char * getNameOfCurrentProject() const = 0;
	virtual void setNameOfCurrentProject(const char * newName) = 0;
	virtual const char * getNameOfTestedProject() const = 0;
	virtual void setNameOfTestedProject(const char * newName) = 0;
	virtual const char *getOS() const = 0;
	virtual void setOS(const char* _OS) = 0;
	Employee(const char * _name, const char * _address, const char * _EGN, const char *_date, Employee * _boss = nullptr);
	Employee(const char * _name, const char * _address, const char * _EGN,const Date& _date, Employee * _boss = nullptr);
	const char * getName()const;
	const char * getAddress() const;
	const char * getEGN() const;
	const Date& getDate() const;
	const Employee* getBoss()const;
	const char* getPosition()const;
	void setName(const char * _name);
	void setAddress(const char * _address);
	void setEGN(const char * _EGN);
	void setDate(const Date& _date);
	void setDate(const char* _date);
	void setBoss(Employee * _boss);
	void setPosition(const char * _position);
	virtual void save(std::ostream& out)const = 0;
	friend std::ostream& operator << (std::ostream &, std::vector<Employee*>);
	//friend std::istream& operator >> (std::istream &, std::vector<Employee*>&);
};
#endif // !__EMPLOYEE_H__
