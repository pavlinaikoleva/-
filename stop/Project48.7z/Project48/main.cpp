#include<iostream>
#include<fstream>
#include "date.h"
#include "employee.h"
#include "junior.h"
#include "master.h"
#include "tester.h"
#include "company.h"
using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::ifstream;
using std::ofstream;
const int SIZE_CHARS_OF_FILE = 100;
void printOptionToChoose()
{
	cout << "Choose option to develop company" << endl;
	cout << "Press '1' to enter basic information(name,CEO,address) about company" << endl;
	cout << "Press '2' to get basic information(name,CEO,address) about company" << endl;
	cout << "Press '3' to hire new employee" << endl;
	cout << "Press '4' to search information about employee by EGN" << endl;
	cout << "Press '5' to fire the employee with certain EGN" << endl;
	cout << "Press '6' to get information about all employees on certain posiotion" << endl;
	cout << "Press '7' to edit information about employee with certain EGN" << endl;
	cout << "Press '8' to create new team without members" << endl;
	cout << "Press '9' to move employee from one team to other" << endl;
	cout << "Press '10' to delete empty teams" << endl;
	cout << "Press '11' to print information about all teams" << endl;
	cout << "Press '12' to load company from file" << endl;
	cout << "Press '13' to add new employee from file" << endl;
	cout << "Press '14' to add few employees from file" << endl;
	cout << "Press '15' to delete employee by using file" << endl;
	cout << "Press '16' to delete few employee by using file" << endl;
	cout << "Press '17' to safe information about company on file" << endl;
	cout << "Press '18' to print information about all employees" << endl;
	cout << "Press '19' to change the leader of a team" << endl;
	cout << "Press '20' to delete a team" << endl;
	cout << "PRESS ANY OTHER KEY TO EXIT PROGRAM" << endl;

}
void testBaseClasses()
{
	Employee* arr[3];
	Master greatboss;
	greatboss.setName("ico metdiev");
	Master rumen("dragan", "Plachkovci", "8741254710", "10.02.2001", &greatboss, "master programmer", "digitalizirane", "histogrami", "ubuntu");
	rumen.setName("Rumen Raikov");
	Tester i("Ivan Petrov", "boqna", "9102457148", "27.07.2009", &rumen, "tester", "navigation", "linux");
	Junior p("Pavlina Koleva", "Gvardejska", "9704167554", "16.04.2017", &i, "junior", "company");
	arr[0] = &p;
	arr[1] = &rumen;
	arr[2] = &i;
	for (int j = 0;j < 3;j++)
	{
		arr[j]->print();
	}
}
void testCompanyClass()
{
	Company firma;
	firma.addEmployee(new Master("Svetla", "Hristo Botev", "7401238564", "21.04.2008", nullptr, "master programmer", "Enigma", "Enigma", "windows"));
	firma.addEmployee();
	firma.addEmployee();
	firma.addEmployee();
	firma.printEmployeesOfCompany();
	cout << endl;
	firma.searchEmployee("9704167554");
	firma.editEmployee("7401238564");
	firma.printEmployeesByPosition("master programmer");
	cout <<endl;
	firma.fireEmployee("7401238564");
	firma.printEmployeesOfCompany();
}
void testTeams()
{
	Company NashtaFirma;
	NashtaFirma.addEmployee();
	NashtaFirma.addEmployee();
	NashtaFirma.addEmployee();
	NashtaFirma.addEmployee();
	NashtaFirma.printEmployeesByTeams();
	NashtaFirma.addNewTeamWithOutMembers("TeamVirtual");
	NashtaFirma.printEmployeesByTeams();
	NashtaFirma.deleteEmptyTeams();
	NashtaFirma.printEmployeesByTeams();
	NashtaFirma.moveEmployeeFromOneTeamToAnother("9704167554", "company");
	NashtaFirma.printEmployeesByTeams();
}
void testWriteOnFile()
{
	ofstream out("arhiv.txt", std::ios::app);
	Company NashtaFirma("Stefan","ITFuture","Vasil Levski");
	NashtaFirma.addEmployee();
	NashtaFirma.addEmployee();
	NashtaFirma.addEmployee();
	//NashtaFirma.addEmployee();
	NashtaFirma.SaveCompanyOnFile(out);
	out.close();
}
void testReadFromFile()
{
	ifstream input("arhiv.txt");
	Company newCompany;
	newCompany.loadCompanyFromFile(input);
	newCompany.printEmployeesOfCompany();
	newCompany.printEmployeesByTeams();
	input.close();
	Company CopyFirma;
	CopyFirma = newCompany;
	cout << "Check operator =" << endl;
	CopyFirma.printEmployeesOfCompany();
	CopyFirma.printEmployeesByTeams();
	cout << "promenqm copyFirma" << endl;
	CopyFirma.addEmployee();
	CopyFirma.printEmployeesOfCompany();
	CopyFirma.printEmployeesByTeams();
	cout << "promenila li se e parvata firma" << endl;
	newCompany.printEmployeesOfCompany();
	newCompany.printEmployeesByTeams();
}

int main()
{
	Company firm;
	int command;
	do
	{
		printOptionToChoose();
		cout << "Enter command: ";
		cin >> command;
		switch (command)
		{
		case 1: {
			cin.ignore();
			char  bufferNameCompany[SIZE_CHARS_NAME_OF_COMPANY];
			char bufferNameCEO[SIZE_CHARS_CEO];
			char bufferAddress[SIZE_CHARS_ADDRESS_OF_COMPANY];
			cout << "Enter name of Company" << endl;
			cin.getline(bufferNameCompany, SIZE_CHARS_NAME_OF_COMPANY);
			cout << "Enter name of CEO" << endl;
			cin.getline(bufferNameCEO, SIZE_CHARS_CEO);
			cout << "Enter address of Company" << endl;
			cin.getline(bufferAddress, SIZE_CHARS_ADDRESS_OF_COMPANY);
			firm.setNameOfCompany(bufferNameCompany);
			firm.setCEO(bufferNameCEO);
			firm.setAddressOfCompany(bufferAddress);
			break;
		}
		case 2: {
			firm.printInformationAboutCompany();
			break;
		}
		case 3: {
			firm.addEmployee();
			break;
		}
		case 4: {
			cin.ignore();
			char buffEGN[SIZE_CHARS_OF_EGN];
			cout << "Enter EGN of the employee you want to search for" << endl;
			cin.getline(buffEGN, SIZE_CHARS_OF_EGN);
			firm.searchEmployee(buffEGN);
			break;
		}
		case 5: {
			cin.ignore();
			char buffEGN[SIZE_CHARS_OF_EGN];
			cout << "Enter EGN of the employee you want to fire" << endl;
			cin.getline(buffEGN, SIZE_CHARS_OF_EGN);
			firm.fireEmployee(buffEGN);
			break;
		}
		case 6: {
			cin.ignore();
			char buffPosition[SIZE_CHARS_OF_POSITION];
			cout << "Enter position of the employees you want to print" << endl;
			cin.getline(buffPosition, SIZE_CHARS_OF_POSITION);
			firm.printEmployeesByPosition(buffPosition);
			break;
		}
		case 7: {
			cin.ignore();
			char buffEGN[SIZE_CHARS_OF_EGN];
			cout << "Enter EGN of the employee you want to edit" << endl;
			cin.getline(buffEGN, SIZE_CHARS_OF_EGN);
			firm.editEmployee(buffEGN);
			break;
		}
		case 8: {
			cin.ignore();
			char buffNameOfTeam[SIZE_CHARS_PROJECT];
			cout << "Enter name of new team without members" << endl;
			cin.getline(buffNameOfTeam, SIZE_CHARS_PROJECT);
			firm.addNewTeamWithOutMembers(buffNameOfTeam);
			break;
		}
		case 9:
		{
			cin.ignore();
			char buffEGN[SIZE_CHARS_OF_EGN];
			cout << "Enter EGN of the employee you want to move to another team" << endl;
			cin.getline(buffEGN, SIZE_CHARS_OF_EGN);
			char buffNameFutureOfTeam[SIZE_CHARS_PROJECT];
			cout << "Enter name of his/her new team" << endl;
			cin.getline(buffNameFutureOfTeam, SIZE_CHARS_PROJECT);
			firm.moveEmployeeFromOneTeamToAnother(buffEGN, buffNameFutureOfTeam);
			break;
		}
		case 10:
		{firm.deleteEmptyTeams();
			break;
		}
		case 11:
		{firm.printEmployeesByTeams();
			break;
		}
		case 12:
		{cin.ignore();
		cout << "Enter name of file from which you want to load information about company" << endl;
		char nameOfFile[SIZE_CHARS_OF_FILE];
		cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
		ifstream input(nameOfFile);
		firm.loadCompanyFromFile(input);
		input.close();
		break;
		}
		case 13:
		{
			cin.ignore();
			cout << "Enter name of file from which you want to load information about employee" << endl;
			char nameOfFile[SIZE_CHARS_OF_FILE];
			cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
			ifstream input(nameOfFile);
			firm.loadEmployee(input);
			input.close();
			break;
		}
		case 14:
		{	cin.ignore();
			int cntNewEmployees;
			cout << "Enter name of file from which you want to load information about employees" << endl;
			char nameOfFile[SIZE_CHARS_OF_FILE];
			cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
			ifstream input(nameOfFile);
			input >> cntNewEmployees;
			for (int i = 0;i < cntNewEmployees;i++)
			{
				firm.loadEmployee(input);
			}
			input.close();
			break;
		}
		case 15:
		{
			cin.ignore();
			char buffEGN[SIZE_CHARS_OF_EGN];
			cout << "Enter name of file from which you want to get information " << endl;
			char nameOfFile[SIZE_CHARS_OF_FILE];
			cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
			ifstream input(nameOfFile);
			input.getline(buffEGN, SIZE_CHARS_OF_EGN);
			firm.fireEmployee(buffEGN);
			input.close();
			break;
		}
		case 16:
		{cin.ignore();
		int cntEmployeesToDelete;
		char buffEGN[SIZE_CHARS_OF_EGN];
		cout << "Enter name of file from which you want to get information " << endl;
		char nameOfFile[SIZE_CHARS_OF_FILE];
		cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
		ifstream input(nameOfFile);
		input >> cntEmployeesToDelete;
		for (int i = 0;i < cntEmployeesToDelete;i++)
		{
			input.getline(buffEGN, SIZE_CHARS_OF_EGN);
			firm.fireEmployee(buffEGN);
		}
		break;
		}
		case 17:
		{
			cin.ignore();
			char nameOfFile[SIZE_CHARS_OF_FILE];
			cout << "Enter name of file on whitch you want to safe company" << endl;
			cin.getline(nameOfFile, SIZE_CHARS_OF_FILE);
			ofstream out(nameOfFile);// ��� �� ������ �� � out
			firm.SaveCompanyOnFile(out);
			out.close();
			break;
		}
		case 18:
		{
			firm.printEmployeesOfCompany();
			break;
		}
		case 19:
		{
			cin.ignore();
			char nameOfTeam[SIZE_CHARS_PROJECT];
			cout << "Enter name of team which you want to change the leader of" << endl;
			cin.getline(nameOfTeam, SIZE_CHARS_PROJECT);
			char nameOfNewLeader[SIZE_CHARS_OF_NAME];
			cout << "Enter name of new leader of this team" << endl;
			cin.getline(nameOfNewLeader, SIZE_CHARS_OF_NAME);
			firm.changeTheLeaderOfATeam(nameOfTeam, nameOfNewLeader);
			break;
		}
		case 20:
		{	cin.ignore();
			char nameOfTeam[SIZE_CHARS_PROJECT];
			cout << "Enter name of team which you want to delete" << endl;
			cin.getline(nameOfTeam, SIZE_CHARS_PROJECT);
			firm.deleteTeam(nameOfTeam);
			break;
		}
		default: {
			command = 42;
			break;
		}
		}
	}while (command != 42);
	system("pause");
	return 0;
}